import { Component } from "@angular/core";

@Component({
    selector:'parent-output',
    templateUrl:'./parentOutput.com.html'
})

export class ParentOutput{
    msg="";
    onNotify(message:string):void{
        this.msg+="I am actually "+message
    }
}