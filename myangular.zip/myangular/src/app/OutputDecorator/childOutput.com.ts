import { Component, Output } from "@angular/core";
import { EventEmitter } from "@angular/core";

@Component({
    selector:'child-output',
    templateUrl:'./childOutput.com.html'
})

export class ChildOutput {
  @Output() notify=new EventEmitter();

  
    childCall():void{
       this.notify.emit("get fined from child")
    }
}