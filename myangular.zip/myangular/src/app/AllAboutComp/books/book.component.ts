import { Component } from "@angular/core";
import { books } from "./books";

@Component({
     selector:'books-app',
     templateUrl:'./book.component.html',
     styleUrls:['./book.component.css']
})

export class BooksComp{
  
    Array=null
    constructor()
    {
      this.Array=[  
          new books("Angular",102,3000,"dontknow"),
          new books("Angular1",103,4000,"dontknow"),
          new books("Angular2",104,5000,"dontknow")
      ]
       
    }

}