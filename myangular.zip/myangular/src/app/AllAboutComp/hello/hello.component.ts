import {Component} from '@angular/core';

@Component({
    selector:'hello-app',
    templateUrl: './hello.component.html',
    styleUrls: ['./hello.component.css']
})

export class HelloComp
{
    name:string="hello creating custom Comp"
}