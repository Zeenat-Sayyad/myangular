
//std demo for parametric custom pipe 
import { Pipe, PipeTransform } from '@angular/core';
/*
 * Raise the value exponentially
 * Takes an exponent argument that defaults to 1.
 * Usage:
 *   value | exponentialStrength:exponent
 * Example:
 *   {{ 2 | exponentialStrength:10 }}
 *   formats to: 1024
*/
@Pipe({name: 'exponentialStrength'})
export class ExponentialStrengthPipe implements PipeTransform {
  transform(value: number, exponent: string): number {
    let exp = parseFloat(exponent);
    return Math.pow(value, isNaN(exp) ? 1 : exp);
  }
}
@Pipe({name: 'square'})
export class square implements PipeTransform {
  transform(value: number): number {
    let exp = 2;
    return Math.pow(value, isNaN(exp) ? 1 : exp);
  }
}
@Pipe({name: 'discount'})
export class discount implements PipeTransform {
  transform(oprice: number,disprice:number): number {
    let a=oprice*disprice;
    let b=oprice-a; 
    return b;
  }
}