import { Directive, ElementRef } from '@angular/core';

 @Directive({ selector: '[myHighlight]' })   //name of directive
export class HighlightDirective {
    constructor(el: ElementRef) {
       el.nativeElement.style.backgroundColor = 'yellow';
       el.nativeElement.style.fontSize=20+"px";
    }
}