import {RouterModule} from '@angular/router'
import { HomeComponent } from './Home.component'
import { ContactComponent } from './Contact.component'
import { PageNotFound } from './PageNotFound.comp'
import { ContactChildComponent } from './Contact-Child.com'
import { AboutComponent } from './about.component'
import { AboutHomeComponent } from './abouthome.component'
import { AboutItemComponent } from './aboutItem.component'
import { myAssignment } from '../Assignment/assignment.com'
import { ShowMoreComponent } from '../Assignment/ShowMore.com'

export const routing=RouterModule.forRoot([
    {path:"home",component:HomeComponent},
    {path:"contact",component:ContactComponent,
    children:[
        {path:"contact-child",component:ContactChildComponent}
    ]
    },
    {
        path: "about", component:AboutComponent,
        children: [
          { path: '', component:AboutHomeComponent },
          { path: 'item/:id', component:AboutItemComponent }
        ]
    },
    {path:'product',component:myAssignment,
        children:[
            {path:'ViewMore/:pid',component:ShowMoreComponent}
        ]
    },
    {path:"**",component:PageNotFound}
])
export default routing