import { NgModule } from "@angular/core";
import { AboutComponent } from "./about.component";
import { AboutHomeComponent } from "./abouthome.component";
import { AboutItemComponent } from "./aboutItem.component";
import { ContactChildComponent } from "./Contact-Child.com";
import { ContactComponent } from "./Contact.component";
import { HomeComponent } from "./Home.component";
import { PageNotFound } from "./PageNotFound.comp";
import { BrowserModule } from "@angular/platform-browser";
import { ShowMoreComponent } from "../Assignment/ShowMore.com";
import routing from "./app.routing";
@NgModule({
    declarations:[
        AboutComponent,
        AboutHomeComponent,
        AboutItemComponent,
        ContactChildComponent,
        ContactComponent,
        HomeComponent,
        PageNotFound,
        ShowMoreComponent
    ],
    imports:[
       BrowserModule,routing
    ],
    exports:[

    ]

})
export class RoutingModule{

}