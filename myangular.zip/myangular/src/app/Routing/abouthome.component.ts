import { Component } from '@angular/core';
//import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'about-home',
    template: `<h3 style=color:Red>About Home</h3>`
})
export class AboutHomeComponent { }

