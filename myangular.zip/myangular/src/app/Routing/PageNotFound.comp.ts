import { Component } from "@angular/core";

@Component({
    template:`<h3>Sorry Url Not Found</h3>`
})
export class PageNotFound{
    
}