import {Component, OnInit, OnDestroy} from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'componentB',
  template: 
     `<div id="menu">
        <header><h3>B</h3></header>
       
      </div> 
      `,
   styles: [
     'header {height: 30px; background-color: silver}',
     '#menu { float: left; width: 20%; background-color: yellow;text-align:center }'
   ]
})

export default class ComponentB {
  

  
}