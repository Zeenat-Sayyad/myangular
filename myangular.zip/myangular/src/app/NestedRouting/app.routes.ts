import {RouterModule } from '@angular/router';
import ComponentA from './componentA';
import ComponentB from './componentB';
import ComponentC from './componentC';
import ComponentD from './componentD';
import ComponentE from './componentE';
 
export const Nestedrouting = RouterModule.forRoot([
  // Redirect empty route to /a ComponentA
  
    { path: 'a', component: ComponentA,
          children: [
                      {path:'b', component: ComponentB},
                      {path:'c', component: ComponentC},
                      {path:'d', component: ComponentD},
                      {path:'e', component: ComponentE},
                    ]
    }
]);
export default Nestedrouting