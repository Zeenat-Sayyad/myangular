import {Component} from '@angular/core';

@Component({
  selector: 'component-A',
  template: 
     `<div id="menu">
        <header><h3>A</h3></header>
        
          <a routerLink="b">B</a><br/>
          <a routerLink="c">C</a><br/>
          <a routerLink="d">D</a><br/>
          <a routerLink="e">E</a><br/>
        
      </div> 
      <div><router-outlet></router-outlet></div>`,
   styles: [
     'header {height: 30px; background-color: silver}',
     '#menu { float: left; width: 20%; background-color:pink;text-align:center }'
   ]
})

export default class ComponentA { 
}