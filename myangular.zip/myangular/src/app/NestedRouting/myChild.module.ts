import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import ComponentA from './componentA';
import ComponentB from './componentB';
import ComponentC from './componentC';
import ComponentD from './componentD';
import ComponentE from './componentE';
import Nestedrouting from './app.routes';



@NgModule({
   declarations: [
   
    ComponentA,
    ComponentB,
    ComponentC,
    ComponentD,
    ComponentE,
    
  ],
  imports: [
    BrowserModule,Nestedrouting
   ]
})
export class MyChildModule {
}