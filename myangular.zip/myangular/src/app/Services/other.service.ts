import { Injectable } from '@angular/core';

@Injectable()
export class OtherService {
    public GetMyText() {
        return "Text From Other Service";
    }
}    