import { Component } from "@angular/core";
import { TestService } from "./test.service";

@Component({
    selector:'test-service',
    templateUrl:'./test.component.html',
    providers:[TestService]
})

export class mytestService{
    hello:any
    getC:any
    flag:boolean
    constructor(private obj:TestService){
    
     }

    gethello(){
       this.hello= this.obj.sayhello()
    }
    getCourse(){
        this.flag=true
        this.getC= this.obj.getCourse()
    }
}

