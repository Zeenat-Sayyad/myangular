import { Component } from "@angular/core";

@Component({
    selector:'two-way',
    templateUrl:'./twoway.com.html',
    styleUrls:['./twoway.com.css']
})

export class Twoway{
    hiMessage1:string="Hi There";
    hiMessage2:string="Ola Senorita!!!!!!!";
   Thetitle:string = 'Techno Solutions Ltd';
   num:number;
   total=1;

   fact(){
       for(let i=1;i<=this.num;i++)
       {
        this.total=this.total*i;
       }
       this.num=this.total;
   }
}