import {Component, OnInit } from '@angular/core';
@Component({
    selector:'attr-demo',
    templateUrl:'attrdemo.component.html',
    styleUrls: ['attrdemo.component.css']
    })

export class DemoAttrComponents implements OnInit
{
    svar:string="Style using ngStyle";

    color:string;
    size:number;
    displayText:string;
    visible:boolean;
    ngOnInit() 
    {
        
    this.color = 'red';
    this.size = 50;
    this.displayText = 'show-class';
    this.visible = true;
     }
 }

