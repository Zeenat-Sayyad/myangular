import { Component } from "@angular/core";

@Component({
    selector:'child-app',
    templateUrl: './child.component.html',
     styleUrls:['./child.component.css']
})
export class Child{
name:string="Child"
}