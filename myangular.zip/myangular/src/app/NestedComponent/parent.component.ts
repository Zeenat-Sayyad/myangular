import { Component } from "@angular/core";

@Component({
    selector:'parent-app',
    templateUrl: './parent.component.html',
     styleUrls:['./parent.component.css']
})
export class Parent{
name:string="Parent"
}