import { NgModule } from "@angular/core";
import { browser } from "protractor";
import { BrowserModule } from "@angular/platform-browser";
import { welcome } from "./welcome.component";
import { Sub } from "./Sub.component";



@NgModule({
    declarations:[
          welcome,Sub
    ],
    imports:[
        BrowserModule
    ],
    exports:[welcome,Sub],
 })

export class myModule{
  
}