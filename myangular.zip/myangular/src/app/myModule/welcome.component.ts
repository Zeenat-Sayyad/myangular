import { Component } from "@angular/core";

@Component({
    selector:'wel-app',
    templateUrl: './welcome.component.html'
   
})
export class welcome{
title:string="hello Moto"
}