import { Component, Output } from "@angular/core";
import { EventEmitter } from "@angular/core";

@Component({
    selector:'cal-child',
    templateUrl:'./calchild.com.html'
})
 export class CalchildComponent{
    no1:number;
    no2:number; 
    @Output() notify=new EventEmitter();
    
     Add(){
         this.notify.emit("Total:"+this.no1+this.no2);
     }
 }